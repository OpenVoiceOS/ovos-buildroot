from .vosk import KaldiRecognizer, Model, SpkModel, SetLogLevel

